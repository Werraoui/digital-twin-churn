"""Run the Sentiment Agent on a stored Persona and persist the result."""

from __future__ import annotations

from sqlalchemy.engine import Engine

from src.agents.data_agent.repository import get_persona, save_persona
from src.agents.sentiment_agent.persona_updater import update_persona
from src.agents.sentiment_agent.sentiment_model import analyze
from src.persona.schema import Persona


def enrich_stored_persona(customer_id: str, engine: Engine | None = None) -> Persona:
    """
    Load Persona from the warehouse, enrich it, save it back.

    Other agents should then call get_persona(customer_id).
    """
    persona = get_persona(customer_id, engine=engine)
    persona = update_persona(persona, analyze(persona))
    save_persona(persona, engine=engine)
    return persona
